# Developer documentation (`docs/dev`)

## Entry points (linked from README / user guide)

- [development.md](./development.md) - workflows, tooling, local setup
- [architecture.md](./architecture.md) - high-level crate and data-flow overview
- [migration.md](./migration.md) - Python to Rust migration
- [agent-plan/phase-a-pre-session-truth-source-fix.md](./agent-plan/phase-a-pre-session-truth-source-fix.md) - Phase A-PRE session truth source and durability fix
- [agent-plan/plan-mode-architecture.md](./agent-plan/plan-mode-architecture.md) - Plan Mode runtime architecture
- [agent-plan/todolist-runtime-architecture.md](./agent-plan/todolist-runtime-architecture.md) - TodoList runtime as Plan execution projection
- [agent-plan/plan-todo-implementation-roadmap.md](./agent-plan/plan-todo-implementation-roadmap.md) - technical roadmap for Plan + TodoList implementation
- [main-closeout-plan-2026-06.md](./main-closeout-plan-2026-06.md) - closeout rules for keeping `main` backend-only and clean
- [main-closeout-cards-2026-06.md](./main-closeout-cards-2026-06.md) - executable cards for splitting the current mixed `main` working tree
- [Observability/phase-b-thin-observability-layer.md](./Observability/phase-b-thin-observability-layer.md) - Phase B thin trace/log/debug-bundle planning
- [archive/nano/agent-diva-nano-master-spec.md](./archive/nano/agent-diva-nano-master-spec.md) - archived nano/shared-runtime packaging index and reference pointers
- [bug-fixing-lessons-learned.md](./bug-fixing-lessons-learned.md) - detailed case studies of complex bugs and their solutions

## Archived material (`archive/`)

Long-form design notes, nano/packaging narratives, roadmaps, and research live under [`archive/`](./archive/). Start from the index:

- [**Nano / packaging index**](archive/nano/agent-diva-nano-master-spec.md) - boundaries, literature links, archive pointers
- [**Roadmaps / follow-ups**](archive/roadmaps/) - provider catalog plan, selection follow-ups, SOUL checklist
- [**QA**](archive/qa/blackbox-test-checklist.md) - manual black-box checklist
- [**Research**](archive/research/README.md) - standalone bundle and Windows packaging notes
- [**Architecture reports**](archive/architecture-reports/README.md) - OpenClaw / Zeroclaw / SOUL deep dives
