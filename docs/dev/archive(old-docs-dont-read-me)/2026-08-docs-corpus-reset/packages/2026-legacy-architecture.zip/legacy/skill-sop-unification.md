# Skill 与 SOP 产品边界决策

- 状态：`Deferred`
- 日期：2026-07-30

> **2026-08-13 superseded for Evolution construction:** 本文保留为历史决策，
> 但“SOP 只是 Skill 的自然语言称呼”不再视为已冻结结论。真实测试促使项目暂停旧
> AutoDream–Evolution 链路，并重新调研 GenericAgent 的渐进沉淀模型。当前有效边界、
> 已确认删除方向和未决问题见
> `docs/research/evolution-genericagent-reset-2026-08/decision-record.md`。在专项调研完成前，
> 不实施本文的 Skill 编辑器方向，也不实施 SOP Candidate → Skill 晋升模型。

## 最终边界

Agent Diva 的产品对象只有 **Skill**。SOP 不是独立类型、能力或子系统：

- 不增加 `kind: sop` 等专用元数据；
- 不显示 `AGENT-DIVA SOP` 专用标签；
- 不增加 SOP 页面、编辑器、DTO、API、目录、注册表或运行时；
- 不根据标题、描述或正文猜测一个 Skill 是否为 SOP；
- 不因用户把某个 Skill 称为 SOP 而改变权限、加载或执行行为。

“SOP”只是一种自然语言称呼，表示某个 Skill 的内容可能描述标准操作流程。
在存储、安装、发现、安全审查、授权和执行层面，它仍然只是普通 `SKILL.md`。

## 未来产品方向

如果未来恢复这项工作，目标不是建设“SOP 编辑器”，而是建设覆盖所有 Skill 的
可视化全生命周期管理：

1. 创建 Skill；
2. 查看和预览 `SKILL.md` 及受支持资源；
3. 编辑元数据、正文和资源引用；
4. 删除 Skill，并明确作用域和恢复策略；
5. 校验格式、依赖、路径边界和兼容性；
6. 执行现有安全扫描与权限说明；
7. 区分内置、用户级、工作区级和插件提供的只读/可编辑来源；
8. 对冲突、覆盖、升级和外部修改提供明确提示。

创建、编辑和删除必须作用于同一个 Skill 领域模型和生命周期，不允许 GUI 再维护
一份独立真相源。删除操作需要确认、精确目标、可恢复策略和审计；插件或内置的
只读 Skill 不得伪装成可编辑。

## 非目标

- Workflow/SOP DSL；
- 独立 SOP Engine；
- SOP Marketplace 分类；
- 基于 SOP 名称的自动触发；
- 隐式提高权限或绕过审批；
- Notebook 到 SOP 的特殊持久化通道。

如果 Notebook 未来支持“固化流程”，它只能调用普通 Skill 创建能力，生成可由
用户继续编辑和审查的标准 Skill 草稿。

## 延期决定

此能力不在当前产品预期和 B5 默认路线中，严重度调整为 `sev-P3` 延期候选。
在用户明确恢复之前：

- 不创建实现 story；
- 不改 Skill schema、Manager/Tauri DTO 或 GUI；
- 不为 `kind: sop` 预留兼容负担；
- 不阻断 G2D、Evolution 重盘点、GMH 或发布收口。

恢复时必须先补充产品规格、来源/权限矩阵、编辑与删除威胁模型、迁移策略和真实
GUI 验收方案，再决定实施分期。
